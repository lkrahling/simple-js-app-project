alert('Hello world');

let favoriteFood = 'Pizza';
document.write(favoriteFood);

